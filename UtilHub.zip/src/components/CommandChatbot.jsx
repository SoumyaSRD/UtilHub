import React, { useState, useEffect, useRef } from 'react';
import { registeredUtilities, generateSystemPromptFromRegistry } from '../utils/registry.js';

// Pre-defined quick command prompts for demonstration
const SAMPLE_COMMANDS = [
  'Yo, make this chatbox float up in the air at 80% intensity for 8 seconds!',
  'Encode the text "Deepmind Advanced Coding" into base64',
  'Inspect localstorage keys',
  'Trigger a system alert ping at 600 Hz',
  'Make the page float gently at 35% for 4 seconds',
];

/**
 * Dynamically ensures that Puter.js is loaded into the browser environment
 */
function ensurePuterJsLoaded() {
  return new Promise((resolve) => {
    if (typeof window === 'undefined') {
      resolve(null);
      return;
    }
    if (window.puter && window.puter.ai) {
      resolve(window.puter);
      return;
    }
    const existing = document.querySelector('script[src*="puter.com"]');
    if (existing) {
      existing.addEventListener('load', () => resolve(window.puter));
      existing.addEventListener('error', () => resolve(null));
      return;
    }
    const script = document.createElement('script');
    script.src = 'https://js.puter.com/v2/';
    script.async = true;
    script.onload = () => resolve(window.puter);
    script.onerror = () => resolve(null);
    document.head.appendChild(script);
  });
}

/**
 * Robust JSON parser that extracts JSON payloads even if wrapped in markdown or conversational text
 */
function extractJsonPayload(rawText) {
  if (!rawText) return null;
  const trimmed = rawText.trim();

  // 1. Direct parse attempt
  try {
    return JSON.parse(trimmed);
  } catch {
    // Continue to markdown extraction
  }

  // 2. Markdown fenced block extraction: ```json { ... } ``` or ``` { ... } ```
  const markdownMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  if (markdownMatch && markdownMatch[1]) {
    try {
      return JSON.parse(markdownMatch[1].trim());
    } catch {
      // Continue to regex scanning
    }
  }

  // 3. Scan for first '{' and last '}'
  const startIdx = trimmed.indexOf('{');
  const endIdx = trimmed.lastIndexOf('}');
  if (startIdx !== -1 && endIdx !== -1 && endIdx > startIdx) {
    const candidate = trimmed.substring(startIdx, endIdx + 1);
    try {
      return JSON.parse(candidate);
    } catch {
      // Failed to parse candidate
    }
  }

  return null;
}

/**
 * Local Semantic Fallback Matcher in case of network/offline issues
 */
function localSemanticFallbackMatcher(input) {
  const lower = input.toLowerCase();

  if (lower.includes('float') || lower.includes('lift') || lower.includes('zero-g') || lower.includes('air') || lower.includes('antigravity')) {
    // Extract intensity
    const intensityMatch = lower.match(/(\d{1,3})\s*%/);
    const intensity = intensityMatch ? Number(intensityMatch[1]) : 70;

    // Extract duration
    const durationMatch = lower.match(/(\d{1,2})\s*(?:second|sec|s\b)/);
    const duration = durationMatch ? Number(durationMatch[1]) : 6;

    // Extract selector
    const selector = lower.includes('body') || lower.includes('page') ? 'body' : '.chatbot-container';

    return {
      action: 'antigravity',
      parameters: { intensity, duration, selector },
      thought: 'Routed via intelligent local semantic parser',
    };
  }

  if (lower.includes('base64') || lower.includes('encode') || lower.includes('decode')) {
    const textMatch = input.match(/"([^"]+)"/) || input.match(/'([^']+)'/);
    const text = textMatch ? textMatch[1] : 'UtilityHub String';
    const isDecode = lower.includes('decode');
    return {
      action: 'string_encoder',
      parameters: { text, encoding: 'base64', mode: isDecode ? 'decode' : 'encode' },
      thought: 'Routed via local encoder parser',
    };
  }

  if (lower.includes('storage') || lower.includes('clean') || lower.includes('cache') || lower.includes('purge')) {
    const isPurge = lower.includes('clean') || lower.includes('purge') || lower.includes('clear');
    return {
      action: 'localstorage_cleaner',
      parameters: { keyPrefix: '', actionType: isPurge ? 'purge' : 'inspect' },
      thought: 'Routed via local storage parser',
    };
  }

  if (lower.includes('ping') || lower.includes('beep') || lower.includes('sound') || lower.includes('alert')) {
    return {
      action: 'ping_notification',
      parameters: { message: 'Command Chatbot Ping', frequency: 520 },
      thought: 'Routed via local notification parser',
    };
  }

  return {
    action: 'UNKNOWN',
    reply: "I am your Autonomous Command Router. You can ask me to float the chatbox (antigravity), encode strings, inspect/purge storage, or ping alerts.",
    parameters: {},
  };
}

export const CommandChatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      id: 'welcome',
      role: 'assistant',
      text: '⚡ Command Terminal Initialized. All registered utility modules introspected. Try typing: "Make this chatbox float in the air at 80% intensity for 8 seconds!"',
      meta: null,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputVal, setInputVal] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [puterReady, setPuterReady] = useState(false);
  const [systemPrompt, setSystemPrompt] = useState('');

  const chatEndRef = useRef(null);
  const inputRef = useRef(null);

  // Initialize discovery engine & Puter.js
  useEffect(() => {
    // Compile meta-programmed system prompt from discovery engine
    const compiledPrompt = generateSystemPromptFromRegistry(registeredUtilities);
    setSystemPrompt(compiledPrompt);

    // Ensure Puter.js is loaded
    ensurePuterJsLoaded().then((puter) => {
      if (puter && puter.ai) {
        setPuterReady(true);
      } else {
        setPuterReady(false);
      }
    });
  }, []);

  // Auto scroll to latest message
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isProcessing]);

  // Focus input on open
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 150);
    }
  }, [isOpen]);

  const handleSendMessage = async (textToSend) => {
    const query = (textToSend || inputVal).trim();
    if (!query || isProcessing) return;

    setInputVal('');

    const userMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    setIsProcessing(true);

    try {
      let parsedResponse = null;

      // 1. Attempt natural language routing via Puter.js AI wrapper
      if (typeof window !== 'undefined' && window.puter && window.puter.ai) {
        try {
          const promptPayload = `${systemPrompt}\n\nUSER REQUEST:\n"${query}"\n\nJSON OUTPUT:`;
          const rawAiOutput = await window.puter.ai.chat(promptPayload);
          const responseString = typeof rawAiOutput === 'string'
            ? rawAiOutput
            : (rawAiOutput?.message?.content || JSON.stringify(rawAiOutput));

          parsedResponse = extractJsonPayload(responseString);
        } catch (puterErr) {
          console.warn('Puter.js execution error, falling back to local semantic parser:', puterErr);
        }
      }

      // 2. Fallback to local semantic matcher if Puter was unavailable or did not produce JSON
      if (!parsedResponse || !parsedResponse.action) {
        parsedResponse = localSemanticFallbackMatcher(query);
      }

      // 3. Execute matched module natively from registry
      const targetActionId = parsedResponse.action;
      const targetParams = parsedResponse.parameters || {};
      const thoughtText = parsedResponse.thought || '';

      if (targetActionId === 'UNKNOWN' || !targetActionId) {
        const replyText = parsedResponse.reply || "I couldn't match that request to any registered utility. Try asking to float this chatbox, encode text, or clean storage.";
        setMessages((prev) => [
          ...prev,
          {
            id: `bot-${Date.now()}`,
            role: 'assistant',
            text: replyText,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
      } else {
        // Look up module in registry
        const matchedModule = registeredUtilities.find((mod) => mod.meta.id === targetActionId);

        let executionLog = '';
        if (matchedModule && typeof matchedModule.execute === 'function') {
          executionLog = matchedModule.execute(targetParams);
        } else {
          executionLog = `❌ Error: Module "${targetActionId}" is not registered in the Discovery Engine.`;
        }

        setMessages((prev) => [
          ...prev,
          {
            id: `bot-${Date.now()}`,
            role: 'assistant',
            text: `🎯 Command dispatched to [${matchedModule?.meta?.name || targetActionId}]`,
            meta: {
              action: targetActionId,
              parameters: targetParams,
              thought: thoughtText,
              executionLog,
            },
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
      }
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: `bot-${Date.now()}`,
          role: 'assistant',
          text: `⚠️ Execution exception: ${err instanceof Error ? err.message : 'Unknown error'}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <>
      {/* Floating Minimized Trigger Icon */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          style={{
            position: 'fixed',
            bottom: '24px',
            right: '24px',
            zIndex: 9990,
            display: 'flex',
            alignItems: 'center',
            gap: '10px',
            padding: '12px 18px',
            borderRadius: '9999px',
            backgroundColor: '#0f172a',
            color: '#f8fafc',
            border: '1px solid rgba(99, 102, 241, 0.4)',
            boxShadow: '0 10px 30px rgba(15, 23, 42, 0.5), 0 0 20px rgba(99, 102, 241, 0.3)',
            cursor: 'pointer',
            transition: 'all 0.25s cubic-bezier(0.16, 1, 0.3, 1)',
            fontFamily: '"JetBrains Mono", Menlo, Consolas, monospace',
            fontSize: '0.875rem',
            outline: 'none',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-3px) scale(1.03)';
            e.currentTarget.style.boxShadow = '0 14px 36px rgba(15, 23, 42, 0.6), 0 0 25px rgba(99, 102, 241, 0.5)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0) scale(1)';
            e.currentTarget.style.boxShadow = '0 10px 30px rgba(15, 23, 42, 0.5), 0 0 20px rgba(99, 102, 241, 0.3)';
          }}
          title="Open Puter.js AI Command Chatbot"
        >
          <span
            style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              backgroundColor: '#10b981',
              boxShadow: '0 0 10px #10b981',
            }}
          />
          <span style={{ fontWeight: 700, color: '#38bdf8' }}>&gt;_</span>
          <span style={{ fontWeight: 600 }}>AI Command Terminal</span>
          <span
            style={{
              fontSize: '0.7rem',
              backgroundColor: 'rgba(99, 102, 241, 0.25)',
              color: '#a5b4fc',
              padding: '2px 8px',
              borderRadius: '9999px',
              border: '1px solid rgba(99, 102, 241, 0.3)',
            }}
          >
            Zero-G
          </span>
        </button>
      )}

      {/* Expanded Terminal Chatbot Window */}
      {isOpen && (
        <div
          className="chatbot-container"
          style={{
            position: 'fixed',
            bottom: '24px',
            right: '24px',
            width: '420px',
            maxWidth: 'calc(100vw - 32px)',
            height: '620px',
            maxHeight: 'calc(100vh - 48px)',
            backgroundColor: 'rgba(15, 23, 42, 0.95)',
            backdropFilter: 'blur(20px)',
            WebkitBackdropFilter: 'blur(20px)',
            border: '1px solid rgba(148, 163, 184, 0.2)',
            borderRadius: '16px',
            boxShadow: '0 25px 60px -12px rgba(0, 0, 0, 0.6), 0 0 35px rgba(99, 102, 241, 0.25)',
            zIndex: 9990,
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
            fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
            color: '#f1f5f9',
          }}
        >
          {/* Terminal Window Title Bar */}
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '12px 16px',
              backgroundColor: 'rgba(30, 41, 59, 0.7)',
              borderBottom: '1px solid rgba(148, 163, 184, 0.15)',
              userSelect: 'none',
            }}
          >
            {/* macOS Window Controls Aesthetic */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <button
                onClick={() => setIsOpen(false)}
                style={{
                  width: '12px',
                  height: '12px',
                  borderRadius: '50%',
                  backgroundColor: '#ef4444',
                  border: 'none',
                  cursor: 'pointer',
                  padding: 0,
                }}
                title="Close terminal"
              />
              <div
                style={{
                  width: '12px',
                  height: '12px',
                  borderRadius: '50%',
                  backgroundColor: '#f59e0b',
                }}
              />
              <div
                style={{
                  width: '12px',
                  height: '12px',
                  borderRadius: '50%',
                  backgroundColor: '#10b981',
                }}
              />
              <span
                style={{
                  marginLeft: '8px',
                  fontFamily: '"JetBrains Mono", monospace',
                  fontSize: '0.8rem',
                  fontWeight: 600,
                  color: '#94a3b8',
                }}
              >
                ai-command-hub ~ zero-g
              </span>
            </div>

            {/* Status Pill */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                fontSize: '0.725rem',
                color: puterReady ? '#34d399' : '#a5b4fc',
                backgroundColor: 'rgba(15, 23, 42, 0.6)',
                padding: '3px 8px',
                borderRadius: '6px',
                border: '1px solid rgba(148, 163, 184, 0.15)',
                fontFamily: '"JetBrains Mono", monospace',
              }}
            >
              <span
                style={{
                  width: '6px',
                  height: '6px',
                  borderRadius: '50%',
                  backgroundColor: puterReady ? '#10b981' : '#6366f1',
                  boxShadow: puterReady ? '0 0 6px #10b981' : 'none',
                }}
              />
              {puterReady ? 'Puter.js AI' : 'Puter AI Ready'}
            </div>
          </div>

          {/* Quick Command Suggestions */}
          <div
            style={{
              display: 'flex',
              gap: '6px',
              padding: '8px 12px',
              backgroundColor: 'rgba(15, 23, 42, 0.4)',
              borderBottom: '1px solid rgba(148, 163, 184, 0.1)',
              overflowX: 'auto',
              whiteSpace: 'nowrap',
              scrollbarWidth: 'none',
            }}
          >
            {SAMPLE_COMMANDS.map((cmd, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(cmd)}
                style={{
                  fontSize: '0.7rem',
                  backgroundColor: 'rgba(51, 65, 85, 0.6)',
                  color: '#cbd5e1',
                  border: '1px solid rgba(100, 116, 139, 0.3)',
                  borderRadius: '4px',
                  padding: '4px 8px',
                  cursor: 'pointer',
                  flexShrink: 0,
                  transition: 'background 0.15s ease',
                  fontFamily: '"JetBrains Mono", monospace',
                }}
                onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'rgba(99, 102, 241, 0.3)')}
                onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'rgba(51, 65, 85, 0.6)')}
              >
                {cmd.length > 34 ? `${cmd.substring(0, 34)}...` : cmd}
              </button>
            ))}
          </div>

          {/* Chat Stream Area */}
          <div
            style={{
              flex: 1,
              overflowY: 'auto',
              padding: '16px',
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
              fontSize: '0.875rem',
            }}
          >
            {messages.map((msg) => {
              const isUser = msg.role === 'user';
              return (
                <div
                  key={msg.id}
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: isUser ? 'flex-end' : 'flex-start',
                  }}
                >
                  {/* Sender & Timestamp */}
                  <div
                    style={{
                      fontSize: '0.7rem',
                      color: '#64748b',
                      marginBottom: '4px',
                      fontFamily: '"JetBrains Mono", monospace',
                    }}
                  >
                    {isUser ? `USER ${msg.timestamp}` : `PUTER_ROUTER ${msg.timestamp}`}
                  </div>

                  {/* Message Bubble */}
                  <div
                    style={{
                      maxWidth: '85%',
                      padding: '10px 14px',
                      borderRadius: isUser ? '14px 14px 2px 14px' : '14px 14px 14px 2px',
                      backgroundColor: isUser ? '#3b82f6' : 'rgba(30, 41, 59, 0.85)',
                      color: '#ffffff',
                      border: isUser ? 'none' : '1px solid rgba(148, 163, 184, 0.2)',
                      boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
                      lineHeight: 1.5,
                      wordBreak: 'break-word',
                    }}
                  >
                    {msg.text}

                    {/* Metadata breakdown if tool was executed */}
                    {msg.meta && (
                      <div
                        style={{
                          marginTop: '10px',
                          paddingTop: '8px',
                          borderTop: '1px solid rgba(148, 163, 184, 0.2)',
                          fontSize: '0.775rem',
                          fontFamily: '"JetBrains Mono", monospace',
                        }}
                      >
                        {/* Action badge */}
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '6px' }}>
                          <span
                            style={{
                              backgroundColor: 'rgba(99, 102, 241, 0.25)',
                              color: '#a5b4fc',
                              padding: '2px 6px',
                              borderRadius: '4px',
                              fontWeight: 700,
                            }}
                          >
                            ACTION: {msg.meta.action}
                          </span>
                        </div>

                        {/* Parameter tags */}
                        {msg.meta.parameters && Object.keys(msg.meta.parameters).length > 0 && (
                          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px', marginBottom: '6px' }}>
                            {Object.entries(msg.meta.parameters).map(([key, val]) => (
                              <span
                                key={key}
                                style={{
                                  backgroundColor: 'rgba(51, 65, 85, 0.7)',
                                  color: '#e2e8f0',
                                  padding: '1px 6px',
                                  borderRadius: '3px',
                                  fontSize: '0.7rem',
                                }}
                              >
                                {key}: {JSON.stringify(val)}
                              </span>
                            ))}
                          </div>
                        )}

                        {/* Execution Log output */}
                        {msg.meta.executionLog && (
                          <div
                            style={{
                              backgroundColor: 'rgba(2, 6, 23, 0.75)',
                              border: '1px solid rgba(56, 189, 248, 0.25)',
                              color: '#38bdf8',
                              padding: '8px',
                              borderRadius: '6px',
                              marginTop: '6px',
                              whiteSpace: 'pre-wrap',
                            }}
                          >
                            {msg.meta.executionLog}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Processing state indicator */}
            {isProcessing && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#94a3b8' }}>
                <span
                  style={{
                    display: 'inline-block',
                    width: '12px',
                    height: '12px',
                    borderRadius: '50%',
                    border: '2px solid #6366f1',
                    borderTopColor: 'transparent',
                    animation: 'spin 0.8s linear infinite',
                  }}
                />
                <style>{`@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }`}</style>
                <span style={{ fontSize: '0.8rem', fontFamily: '"JetBrains Mono", monospace' }}>
                  Evaluating intent via Puter.js AI...
                </span>
              </div>
            )}

            <div ref={chatEndRef} />
          </div>

          {/* Terminal Input Bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              padding: '12px 14px',
              backgroundColor: 'rgba(30, 41, 59, 0.7)',
              borderTop: '1px solid rgba(148, 163, 184, 0.15)',
            }}
          >
            <span
              style={{
                color: '#38bdf8',
                fontFamily: '"JetBrains Mono", monospace',
                fontWeight: 800,
                userSelect: 'none',
              }}
            >
              &gt;
            </span>

            <input
              ref={inputRef}
              type="text"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              placeholder="e.g. Make this chatbox float at 80% for 8s..."
              disabled={isProcessing}
              style={{
                flex: 1,
                backgroundColor: 'transparent',
                border: 'none',
                outline: 'none',
                color: '#f8fafc',
                fontSize: '0.875rem',
                fontFamily: '"JetBrains Mono", Menlo, Consolas, monospace',
              }}
            />

            <button
              type="submit"
              disabled={!inputVal.trim() || isProcessing}
              style={{
                backgroundColor: inputVal.trim() && !isProcessing ? '#3b82f6' : 'rgba(100, 116, 139, 0.2)',
                color: inputVal.trim() && !isProcessing ? '#ffffff' : '#64748b',
                border: 'none',
                borderRadius: '6px',
                padding: '6px 14px',
                fontSize: '0.8rem',
                fontWeight: 600,
                cursor: inputVal.trim() && !isProcessing ? 'pointer' : 'default',
                transition: 'all 0.15s ease',
                fontFamily: '"JetBrains Mono", monospace',
              }}
            >
              EXEC
            </button>
          </form>
        </div>
      )}
    </>
  );
};

export default CommandChatbot;
